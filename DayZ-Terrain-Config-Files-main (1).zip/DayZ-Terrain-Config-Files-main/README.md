# DayZ Terrain Config Files
 Default files needed when creating a custom map

# Other Needed Tools

QGIS
https://qgis.org/en/site/forusers/download.html

QGIS Map Addon
https://gitlab.com/Adanteh/qgis-game-terrains/-/wikis/home

DayZ Tools
(In your steam library)

DeOgg
dayz2p
DePbo
MakePbo
PboProject
https://mikero.bytex.digital/Downloads


DayZCommunityOfflineMode
https://github.com/Arkensor/DayZCommunityOfflineMode